module.exports = {
  token: "", // Your Bot Token Here
  prefix: ";",
  owner: "1050641070368772166" // Your discord id
}