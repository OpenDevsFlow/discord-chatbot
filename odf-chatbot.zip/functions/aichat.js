const { NextChat } = require("enplex.js");

module.exports = async (bot, content, message) => {
  const prompt = content
    .replace(`<@${bot.user.id}>`, "")
    .replace(/<@!?\d+>/g, message.mentions.members.map(member => `@${member.user.username}`).shift() || "")
    .trim();

  try {
    if (prompt.length === 0) {
      return await message.reply("Hey, whats going on?");
    }

    if (prompt.startsWith("Imagine") || prompt.startsWith("imagine")) {
      const wait = await message.reply("Processing your request...");
      return await require("./imagine.js")(bot, prompt, wait);
    }

    const resp = await NextChat.ask(prompt, { model: "gemini" });
      
    for (let i = 0; i < resp.length; i += 2000) {
      const chunk = resp.substring(i, i + 2000);
      await message.reply(chunk);
    }
    return;
  } catch (err) {
    console.error(err);
    return await message.reply("An error occurred while processing your request... please try again later.");
  }
};