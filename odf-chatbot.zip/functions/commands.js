const fs = require('node:fs');

module.exports = (bot) => {
  const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

  for (const file of commandFiles) {
    const name = file.replace(/\.js|_/g, '').trim();

    const command = require(`../commands/${file}`);

    if (file.startsWith('_')) {
      bot.ownerCommands.set(name, command);
      console.log(`[OWNER COMMAND LOADED] ${name}`);
      continue;
    }

    bot.commands.set(name, command);
    console.log(`[COMMAND LOADED] ${name}`);
    continue;
  }
  return;
};