const { EmbedBuilder } = require("discord.js");
const { NextChat } = require("enplex.js");

module.exports = async (bot, prompt, message) => {
  const resp = await NextChat.imagine(prompt, { model: "prodia" });
  
  const embed = new EmbedBuilder()
    .setTitle("Image Generated")
    .setDescription(`**Prompt**: **${prompt}**\n**Model**: **Prodia**`)
    .setImage(resp[0])
    .setColor('#ADD8E6')
    .setFooter({
      text: "Powered by enplex.js",
      iconURL: bot.user.displayAvatarURL(),
    })
    .setTimestamp();

  return await message.edit({ content: "", embeds: [embed] });
}