const { EmbedBuilder } = require("discord.js");

module.exports = async (bot, content, message) => {
  const serverUrl = "https://discord.gg/Qn5N7gQEcr";

  const embed = new EmbedBuilder()
    .setColor("Random")
    .setTitle("Support Server Link")
    .setDescription(`[Click here](${serverUrl}) to join our support server!`)
    .setColor('#ADD8E6')
    .setFooter({
      text: "Powered by enplex.js",
      iconURL: bot.user.displayAvatarURL(),
    })
    .setTimestamp();

  return await message.reply({ embeds: [embed] });
};