const { EmbedBuilder } = require("discord.js");

module.exports = async (bot, content, message) => {
  const messageLatency = Date.now() - message.createdTimestamp;
  const apiLatency = bot.ws.ping;

  const embed = new EmbedBuilder()
    .setTitle("Pong!")
    .setDescription(`**Bot Latency**: ${messageLatency}ms\n**API Latency**: ${apiLatency}ms\n**Total Latency**: ${messageLatency + apiLatency}ms`)
    .setColor('#ADD8E6')
    .setFooter({
      text: "Powered by enplex.js",
      iconURL: bot.user.displayAvatarURL(),
    })
    .setTimestamp();

  return await message.reply({ embeds: [embed] });
};