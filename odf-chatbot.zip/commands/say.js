module.exports = async (bot, content, message) => {
  if (content.length === 0) {
    return await message.reply("Please say something.")
  }
  await message.delete();
  return await message.channel.send(content);
}