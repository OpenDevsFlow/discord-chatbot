const { EmbedBuilder } = require("discord.js");

module.exports = async (bot, content, message) => {
  const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${bot.user.id}&permissions=8&integration_type=0&scope=bot`;
  const embed = new EmbedBuilder()
    .setColor("Random")
    .setTitle("Invite Link")
    .setDescription(`[Click here](${inviteUrl}) to invite me to your server!`)
    .setColor('#ADD8E6')
    .setFooter({
      text: "Powered by enplex.js",
      iconURL: bot.user.displayAvatarURL(),
    })
    .setTimestamp();

  return await message.reply({ embeds: [embed] });
};