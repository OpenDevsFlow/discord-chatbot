const { token } = require ("../config/index.js");

module.exports = async (bot, content, message) => {
  const reloading = await message.reply("Reloading...");

  if (!content) {
    await bot.destroy();
    await bot.login(token);
    return await reloading.edit({ content: "Bot has been successfully reloaded." });
  } else {
    await require("../functions/commands.js")(bot);
    return await reloading.edit({ content: "Bot commands has been successfully reloaded." });
  }
};