module.exports = async (bot, content, message) => {
  const input = content;
  const msg = await message.reply("evaluating...");
  if (input.includes("bot.token")) {
    return await msg.edit({ content: 'Uh sorry, I am not gonna share my token!' });
  }
  return await msg.edit({ content: '```bash\n' + eval(input.replace(/^(```js)|(```)$/gi, "")) + '\n```' });
};