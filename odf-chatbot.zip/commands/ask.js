const { sendTyping } = require("discord.js");

module.exports = async (bot, content, message) => {
  message.channel.sendTyping();

  return await require("../functions/aichat.js")(bot, content, message);
};