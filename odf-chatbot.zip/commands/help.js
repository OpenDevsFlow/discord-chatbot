const { EmbedBuilder } = require("discord.js");
const { prefix } = require("../config/index.js");

module.exports = async (bot, content, message) => {
  const embed = new EmbedBuilder()
    .setColor("Random")
    .setTitle("Help Panel")
    .setDescription(`Mention me and ask anything!\nMy command prefix is: **${prefix}**`)
    .addFields([
      {
        name: "· AI Commands",
        value: "> **ask**: Ask me anything.\n> **imagine**: Generates an image based on the given prompt.\n> **tts**: Generates an audio of the given prompt. [NOT ADDED YET]\n> **upscale**: Enhance the image from the given url. [NOT ADDED YET]",
        inline: true,
      },
      {
        name: "· Fun Commands",
        value: "> **say**: Make the bot to say anything.",
        inline: true
      },
      {
        name: "· Bot Commands",
        value: "> **ping**: Displays the bot's latency.\n> **invite**: Displays the bot's invite link.\n> **support**: Displays the bot's support server link.",
        inline: true,
      },
      {
        name: "· Owner Commands",
        value: "> **reload**: Reloads the bot and commands.\n> **eval**: Evaluate the given code [NOT SECURE].",
        inline: true,
      },
    ])
    .setColor('#ADD8E6')
    .setFooter({
      text: "Powered by enplex.js",
      iconURL: bot.user.displayAvatarURL(),
    })
    .setTimestamp();

  return await message.reply({ embeds: [embed] });
};