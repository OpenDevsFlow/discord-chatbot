module.exports = async (bot, content, message) => {
  const msg = await message.reply("Processing your request...");

  return await require("../functions/imagine.js")(bot, content, msg);
};