const { Client, GatewayIntentBits, Collection, Options, sendTyping } = require("discord.js");
const { token, prefix, owner } = require("./config/index.js");

const bot = new Client({
  shards: "auto",
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ]
});

bot.commands = new Collection();
bot.ownerCommands = new Collection();

process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception: ", err);
});
process.on("unhandledRejection", (err) => {
  console.error("Unhandled Rejection: ", err);
});

bot.once("ready", () => {
  require("./functions/commands.js")(bot);
  console.log("Bot is ready!");
});

bot.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const content = message.content.toLowerCase();

  if (message.mentions.has(bot.user) && !message.mentions.everyone && !message.mentions.here) {
    message.channel.sendTyping();
    return await require('./functions/aichat.js')(bot, message.content, message);
  }

  if (!message.content.startsWith(prefix)) return;

  const args = content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  const command = bot.commands.get(commandName) || bot.ownerCommands.get(commandName);

  if (!command) return message.reply('Invalid command!');

  if (commandName in bot.ownerCommands && message.author.id === owner) {
    return message.reply('This command is only for bot owners!');
  }

  try {
    await command(bot, message.content.replace(prefix + commandName, "").trim(), message); 
  } catch (error) {
    console.error(`[COMMAND ERROR] ${error}`);
    await message.reply('An error occurred while executing the command.');
  }
});

bot.login(token).catch((err) => {
  console.error(err);
  return process.exit();
});